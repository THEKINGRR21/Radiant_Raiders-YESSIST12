import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import UploadPage from './pages/UploadPage';
import DashboardPage from './pages/DashboardPage';
import ReportsPage from './pages/ReportsPage';
import LoginPage from './pages/LoginPage';
import { useAuthStore } from './store/authStore';

enum Page {
  Home,
  Upload,
  Dashboard,
  Reports
}

function App() {
  const [currentPage, setCurrentPage] = React.useState<Page>(Page.Home);
  const isAuthenticated = useAuthStore(state => state.isAuthenticated);

  const renderPage = () => {
    if (!isAuthenticated) {
      return <LoginPage />;
    }

    switch (currentPage) {
      case Page.Home:
        return <HomePage />;
      case Page.Upload:
        return <UploadPage />;
      case Page.Dashboard:
        return <DashboardPage />;
      case Page.Reports:
        return <ReportsPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {isAuthenticated && <Header />}
      
      {isAuthenticated && (
        <div className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-center space-x-8 py-4">
              <button
                onClick={() => setCurrentPage(Page.Home)}
                className={`px-3 py-2 text-sm font-medium ${
                  currentPage === Page.Home 
                    ? 'text-teal-600 border-b-2 border-teal-600' 
                    : 'text-gray-500 hover:text-teal-600'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => setCurrentPage(Page.Upload)}
                className={`px-3 py-2 text-sm font-medium ${
                  currentPage === Page.Upload 
                    ? 'text-teal-600 border-b-2 border-teal-600' 
                    : 'text-gray-500 hover:text-teal-600'
                }`}
              >
                Upload X-Ray
              </button>
              <button
                onClick={() => setCurrentPage(Page.Dashboard)}
                className={`px-3 py-2 text-sm font-medium ${
                  currentPage === Page.Dashboard 
                    ? 'text-teal-600 border-b-2 border-teal-600' 
                    : 'text-gray-500 hover:text-teal-600'
                }`}
              >
                Dashboard
              </button>
              <button
                onClick={() => setCurrentPage(Page.Reports)}
                className={`px-3 py-2 text-sm font-medium ${
                  currentPage === Page.Reports 
                    ? 'text-teal-600 border-b-2 border-teal-600' 
                    : 'text-gray-500 hover:text-teal-600'
                }`}
              >
                Reports
              </button>
            </div>
          </div>
        </div>
      )}
      
      <main className="flex-grow">
        {renderPage()}
      </main>
      
      {isAuthenticated && <Footer />}
    </div>
  );
}

export default App;