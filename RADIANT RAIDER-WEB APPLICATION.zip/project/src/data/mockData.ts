import { UploadedImage, AnalysisResult, ImageClassification } from '../types';

// Helper function to create a random date within the last 30 days
const randomDate = () => {
  const date = new Date();
  date.setDate(date.getDate() - Math.floor(Math.random() * 30));
  return date.toISOString();
};

// Helper function to create a random analysis result
const createAnalysisResult = (id: string, classification: ImageClassification): AnalysisResult => {
  const recommendations = {
    accepted: [
      "The implant is correctly positioned and shows no signs of issues. Continue with your regular check-up schedule.",
      "Your implant is in excellent condition. No intervention required at this time. Follow up in 6 months.",
      "All parameters are within normal range. The implant is functioning as expected. Continue prescribed medication."
    ],
    rejected: [
      "The implant shows signs of rejection. Please consult with your physician immediately for possible removal.",
      "Implant rejection detected. Anti-inflammatory treatment recommended. Schedule an appointment within 48 hours.",
      "Immune response detected around the implant area. Further assessment required. Contact your specialist."
    ],
    infected: [
      "Signs of infection detected around the implant. Antibiotic treatment recommended. Consult your doctor immediately.",
      "Bacterial infection likely present. Urgent medical attention required. Start prescribed antibiotics immediately.",
      "Moderate infection observed. Drainage and antibiotic therapy recommended. Schedule an emergency appointment."
    ],
    disinfected: [
      "Previous infection has been resolved. Continue monitoring for any recurring symptoms.",
      "Disinfection process successful. The implant area shows good healing. Continue with current treatment.",
      "Post-treatment scan shows no remaining infection. Complete your antibiotic course as prescribed."
    ]
  };

  const confidenceRanges = {
    accepted: [0.85, 0.98],
    rejected: [0.82, 0.95],
    infected: [0.80, 0.93],
    disinfected: [0.83, 0.96]
  };

  // Get random recommendation for the classification
  const recommendationList = recommendations[classification as keyof typeof recommendations] || [];
  const recommendation = recommendationList[Math.floor(Math.random() * recommendationList.length)];

  // Get random confidence value for the classification
  const confidenceRange = confidenceRanges[classification as keyof typeof confidenceRanges] || [0.7, 0.9];
  const confidence = confidenceRange[0] + Math.random() * (confidenceRange[1] - confidenceRange[0]);

  return {
    id,
    classification,
    confidence,
    recommendation: recommendation || "No specific recommendation available.",
    date: randomDate()
  };
};

// Create mock images with analysis results
export const mockImages: UploadedImage[] = [
  {
    id: '1',
    url: 'https://images.pexels.com/photos/4225932/pexels-photo-4225932.jpeg',
    name: 'Knee_Implant_X_Ray.jpg',
    date: randomDate(),
    result: createAnalysisResult('1', 'accepted')
  },
  {
    id: '2',
    url: 'https://images.pexels.com/photos/6749773/pexels-photo-6749773.jpeg',
    name: 'Hip_Replacement_Scan.jpg',
    date: randomDate(),
    result: createAnalysisResult('2', 'rejected')
  },
  {
    id: '3',
    url: 'https://images.pexels.com/photos/4226765/pexels-photo-4226765.jpeg',
    name: 'Dental_Implant_X_Ray.jpg',
    date: randomDate(),
    result: createAnalysisResult('3', 'infected')
  },
  {
    id: '4',
    url: 'https://images.pexels.com/photos/3825539/pexels-photo-3825539.jpeg',
    name: 'Spinal_Implant_Scan.jpg',
    date: randomDate(),
    result: createAnalysisResult('4', 'disinfected')
  }
];

// Initial chat messages
export const initialMessages = [
  {
    id: '1',
    content: 'Hello! I\'m your Medical Assistant. How can I help you today?',
    sender: 'system',
    timestamp: new Date().toISOString()
  }
];