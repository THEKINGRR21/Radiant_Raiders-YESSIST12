import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Dashboard from '../components/Dashboard';
import RecentImages from '../components/RecentImages';
import AnalysisResult from '../components/AnalysisResult';
import { mockImages } from '../data/mockData';
import { UploadedImage } from '../types';
import { Calendar, Clock, MapPin, User, Plus, Stethoscope, Activity } from 'lucide-react';

interface Appointment {
  id: string;
  doctorName: string;
  specialty: string;
  date: string;
  time: string;
  location: string;
  type: string;
}

const initialAppointments: Appointment[] = [
  {
    id: '1',
    doctorName: 'Dr. Johnson',
    specialty: 'Radiology',
    date: 'June 15, 2025',
    time: '10:30 AM',
    location: 'Medical Imaging Center',
    type: 'Follow-up Scan'
  },
  {
    id: '2',
    doctorName: 'Dr. Smith',
    specialty: 'Orthopedics',
    date: 'July 3, 2025',
    time: '2:15 PM',
    location: 'Orthopedic Clinic',
    type: 'Implant Check'
  },
  {
    id: '3',
    doctorName: 'Dr. Patel',
    specialty: 'Infectious Disease',
    date: 'July 15, 2025',
    time: '11:00 AM',
    location: 'Medical Center',
    type: 'Consultation'
  }
];

const DashboardPage: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<UploadedImage | null>(null);
  const [showNewAppointment, setShowNewAppointment] = useState(false);
  const [appointments] = useState<Appointment[]>(initialAppointments);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12"
    >
      <div className="mb-8">
        <div className="flex items-center space-x-3">
          <Activity className="h-8 w-8 text-teal-600" />
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        </div>
        <p className="mt-2 text-gray-600 ml-11">Monitor your implant health and upcoming appointments</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Dashboard images={mockImages} />
          </motion.div>
          
          {selectedImage && selectedImage.result && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-6 rounded-xl shadow-lg border border-gray-100"
            >
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-medium text-gray-900">Selected Analysis</h2>
                <button 
                  onClick={() => setSelectedImage(null)}
                  className="text-gray-400 hover:text-gray-500 transition-colors"
                >
                  <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="relative rounded-xl overflow-hidden shadow-inner">
                    <img 
                      src={selectedImage.url} 
                      alt={selectedImage.name} 
                      className="w-full h-auto max-h-64 object-cover"
                    />
                  </div>
                  <p className="mt-2 text-sm text-gray-500">{selectedImage.name}</p>
                  <p className="text-xs text-gray-400">Uploaded on {new Date(selectedImage.date).toLocaleDateString()}</p>
                </div>
                <div>
                  <AnalysisResult result={selectedImage.result} loading={false} />
                </div>
              </div>
            </motion.div>
          )}
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white p-6 rounded-xl shadow-lg border border-gray-100"
          >
            <h2 className="text-xl font-medium text-gray-900 mb-6">Treatment Progress</h2>
            <div className="relative">
              <div className="absolute inset-0 flex items-center" aria-hidden="true">
                <div className="w-full border-t-2 border-gray-200"></div>
              </div>
              <div className="relative flex justify-between">
                {['Initial Scan', 'Treatment Started', 'Follow-up', 'Current Status'].map((step, index) => (
                  <motion.span
                    key={index}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    className="relative bg-white px-2 text-sm text-gray-600 font-medium"
                  >
                    <div className={`h-4 w-4 rounded-full ${index === 3 ? 'bg-teal-500 ring-4 ring-teal-100' : 'bg-gray-300'} mx-auto mb-2`}></div>
                    {step}
                  </motion.span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
        
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-8"
        >
          <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
            <div className="bg-gradient-to-r from-teal-500 to-teal-600 px-4 py-4 flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <Stethoscope className="h-5 w-5 text-white" />
                <h3 className="text-lg font-medium text-white">Appointments</h3>
              </div>
              <button
                onClick={() => setShowNewAppointment(!showNewAppointment)}
                className="inline-flex items-center px-3 py-1 rounded-md text-teal-600 bg-white hover:bg-teal-50 transition-colors"
              >
                <Plus className="h-4 w-4 mr-1" />
                <span className="text-sm font-medium">New</span>
              </button>
            </div>
            
            {showNewAppointment && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="p-4 bg-gray-50 border-b border-gray-200"
              >
                <form className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Appointment Type</label>
                    <select className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500">
                      <option>Follow-up Scan</option>
                      <option>Implant Check</option>
                      <option>Consultation</option>
                      <option>Treatment</option>
                    </select>
                  </div>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Date</label>
                      <input type="date" className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Time</label>
                      <input type="time" className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500" />
                    </div>
                  </div>
                  <div className="flex justify-end space-x-3">
                    <button
                      type="button"
                      onClick={() => setShowNewAppointment(false)}
                      className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-2 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-teal-600 hover:bg-teal-700 transition-colors"
                    >
                      Schedule
                    </button>
                  </div>
                </form>
              </motion.div>
            )}
            
            <div className="divide-y divide-gray-200">
              {appointments.map((appointment, index) => (
                <motion.div
                  key={appointment.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className="p-4 hover:bg-gray-50 transition-all duration-200"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-gray-900">{appointment.type}</h4>
                      <div className="mt-1 space-y-1">
                        <div className="flex items-center text-sm text-gray-500">
                          <User className="h-4 w-4 mr-1 text-teal-500" />
                          {appointment.doctorName} ({appointment.specialty})
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Calendar className="h-4 w-4 mr-1 text-teal-500" />
                          {appointment.date}
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Clock className="h-4 w-4 mr-1 text-teal-500" />
                          {appointment.time}
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <MapPin className="h-4 w-4 mr-1 text-teal-500" />
                          {appointment.location}
                        </div>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <button className="text-teal-600 hover:text-teal-700 text-sm font-medium transition-colors">
                        Reschedule
                      </button>
                      <button className="text-red-600 hover:text-red-700 text-sm font-medium transition-colors">
                        Cancel
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default DashboardPage;