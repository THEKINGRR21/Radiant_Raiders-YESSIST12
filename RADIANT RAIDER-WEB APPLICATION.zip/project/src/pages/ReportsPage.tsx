import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Report } from '../types';
import { 
  FileText, 
  Search, 
  Plus, 
  Download, 
  AlertCircle,
  CheckCircle,
  AlertTriangle,
  ChevronDown,
  Upload
} from 'lucide-react';

const initialReports: Report[] = [
  {
    id: '1',
    title: 'Initial Implant Assessment',
    date: '2025-03-15',
    doctorName: 'Dr. Johnson',
    specialty: 'Orthopedics',
    content: 'Patient shows good initial acceptance of the implant. No signs of rejection or infection. Regular monitoring recommended.',
    attachments: ['xray_001.jpg', 'scan_001.pdf'],
    status: 'normal'
  },
  {
    id: '2',
    title: 'Follow-up Examination',
    date: '2025-03-20',
    doctorName: 'Dr. Smith',
    specialty: 'Immunology',
    content: 'Mild inflammation detected around implant area. Prescribed anti-inflammatory medication. Close monitoring required.',
    attachments: ['report_002.pdf'],
    status: 'attention'
  },
  {
    id: '3',
    title: 'Emergency Consultation',
    date: '2025-03-25',
    doctorName: 'Dr. Patel',
    specialty: 'Infectious Disease',
    content: 'Signs of infection detected. Immediate antibiotic treatment initiated. Daily monitoring required.',
    attachments: ['scan_003.jpg', 'lab_results.pdf'],
    status: 'critical'
  }
];

const ReportsPage: React.FC = () => {
  const [reports] = useState<Report[]>(initialReports);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [showNewReport, setShowNewReport] = useState(false);

  const getStatusIcon = (status: Report['status']) => {
    switch (status) {
      case 'normal':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'attention':
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      case 'critical':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
    }
  };

  const getStatusColor = (status: Report['status']) => {
    switch (status) {
      case 'normal':
        return 'bg-green-50 text-green-700 border-green-200';
      case 'attention':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'critical':
        return 'bg-red-50 text-red-700 border-red-200';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <FileText className="h-8 w-8 text-teal-600" />
            <h1 className="text-3xl font-bold text-gray-900">Medical Reports</h1>
          </div>
          <button
            onClick={() => setShowNewReport(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500"
          >
            <Plus className="h-4 w-4 mr-2" />
            New Report
          </button>
        </div>
        <p className="mt-2 text-gray-600 ml-11">View and manage your medical reports and documents</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden">
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center space-x-4">
                <div className="flex-1 relative">
                  <input
                    type="text"
                    placeholder="Search reports..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500"
                  />
                  <Search className="h-5 w-5 text-gray-400 absolute left-3 top-2.5" />
                </div>
                <select className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-teal-500 focus:border-teal-500">
                  <option>All Reports</option>
                  <option>Normal</option>
                  <option>Needs Attention</option>
                  <option>Critical</option>
                </select>
              </div>
            </div>

            <div className="divide-y divide-gray-200">
              {reports.map((report) => (
                <motion.div
                  key={report.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className={`p-4 hover:bg-gray-50 cursor-pointer ${
                    selectedReport?.id === report.id ? 'bg-gray-50' : ''
                  }`}
                  onClick={() => setSelectedReport(report)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      {getStatusIcon(report.status)}
                      <div>
                        <h3 className="text-lg font-medium text-gray-900">{report.title}</h3>
                        <p className="mt-1 text-sm text-gray-500">
                          {report.doctorName} - {report.specialty}
                        </p>
                        <p className="text-sm text-gray-400">
                          {new Date(report.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <ChevronDown className="h-5 w-5 text-gray-400" />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          {selectedReport ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden"
            >
              <div className={`px-4 py-3 ${getStatusColor(selectedReport.status)}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(selectedReport.status)}
                    <h3 className="text-lg font-medium">{selectedReport.title}</h3>
                  </div>
                </div>
              </div>

              <div className="p-4 space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-700">Doctor's Notes</h4>
                  <p className="mt-1 text-gray-600">{selectedReport.content}</p>
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-700">Attachments</h4>
                  <div className="mt-2 space-y-2">
                    {selectedReport.attachments.map((attachment, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 border border-gray-200 rounded-lg"
                      >
                        <span className="text-sm text-gray-600">{attachment}</span>
                        <button className="text-teal-600 hover:text-teal-700">
                          <Download className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <button className="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                    Download Full Report
                  </button>
                </div>
              </div>
            </motion.div>
          ) : (
            <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-8 text-center">
              <FileText className="h-12 w-12 text-gray-400 mx-auto" />
              <h3 className="mt-2 text-lg font-medium text-gray-900">No Report Selected</h3>
              <p className="mt-1 text-gray-500">Select a report to view its details</p>
            </div>
          )}
        </div>
      </div>

      {showNewReport && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-xl shadow-xl max-w-2xl w-full"
          >
            <div className="px-4 py-3 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">New Medical Report</h3>
            </div>

            <div className="p-4">
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Report Title</label>
                  <input
                    type="text"
                    className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Doctor's Name</label>
                    <input
                      type="text"
                      className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Specialty</label>
                    <input
                      type="text"
                      className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Report Content</label>
                  <textarea
                    rows={4}
                    className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500"
                  ></textarea>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Status</label>
                  <select className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-teal-500 focus:border-teal-500">
                    <option value="normal">Normal</option>
                    <option value="attention">Needs Attention</option>
                    <option value="critical">Critical</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Attachments</label>
                  <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                    <div className="space-y-1 text-center">
                      <Upload className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="flex text-sm text-gray-600">
                        <label className="relative cursor-pointer rounded-md font-medium text-teal-600 hover:text-teal-500">
                          <span>Upload files</span>
                          <input type="file" className="sr-only" multiple />
                        </label>
                        <p className="pl-1">or drag and drop</p>
                      </div>
                      <p className="text-xs text-gray-500">PDF, JPG, PNG up to 10MB</p>
                    </div>
                  </div>
                </div>
              </form>
            </div>

            <div className="px-4 py-3 bg-gray-50 flex justify-end space-x-3 rounded-b-xl">
              <button
                onClick={() => setShowNewReport(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button className="px-4 py-2 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-teal-600 hover:bg-teal-700">
                Save Report
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default ReportsPage;