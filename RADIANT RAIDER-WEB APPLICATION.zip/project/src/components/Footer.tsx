import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-50 border-t border-gray-200">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <span className="text-lg font-semibold text-gray-900">Smart Implant Nano Heal</span>
            <p className="mt-2 text-sm text-gray-500">
              Advanced medical implant analysis using cutting-edge AI technology.
            </p>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase">Resources</h3>
            <ul className="mt-4 space-y-4">
              <li><a href="#" className="text-base text-gray-500 hover:text-teal-600">Documentation</a></li>
              <li><a href="#" className="text-base text-gray-500 hover:text-teal-600">Medical References</a></li>
              <li><a href="#" className="text-base text-gray-500 hover:text-teal-600">Research</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wider uppercase">Support</h3>
            <ul className="mt-4 space-y-4">
              <li><a href="mailto:rithusj17@gmail.com" className="text-base text-gray-500 hover:text-teal-600">rithusj17@gmail.com</a></li>
              <li><a href="mailto:rishiraman212005@gmail.com" className="text-base text-gray-500 hover:text-teal-600">rishiraman212005@gmail.com</a></li>
              <li><a href="#" className="text-base text-gray-500 hover:text-teal-600">Privacy Policy</a></li>
              <li><a href="#" className="text-base text-gray-500 hover:text-teal-600">Terms of Service</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 border-t border-gray-200 pt-8">
          <p className="text-sm text-gray-500 text-center">
            &copy; {new Date().getFullYear()} Smart Implant Nano Heal System by Radiant Raiders. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;