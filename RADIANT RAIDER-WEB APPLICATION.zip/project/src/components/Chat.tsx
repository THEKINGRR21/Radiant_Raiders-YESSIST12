import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot } from 'lucide-react';
import { Message } from '../types';

interface ChatProps {
  initialMessages?: Message[];
}

const Chat: React.FC<ChatProps> = ({ initialMessages = [] }) => {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Simulate AI responses
  const generateResponse = (question: string): Promise<string> => {
    // Simulate API delay
    return new Promise((resolve) => {
      setIsTyping(true);
      setTimeout(() => {
        let response = "I'm sorry, I don't have enough information about that.";
        
        // Simple pattern matching for demo purposes
        if (question.toLowerCase().includes('implant')) {
          response = "Smart Implants are advanced medical devices designed to aid healing and monitor health conditions. They're made with biocompatible materials and contain nano-sensors for real-time monitoring.";
        } else if (question.toLowerCase().includes('infection')) {
          response = "Implant infections can be serious. Signs include redness, swelling, pain, and fever. If your scan shows infection, please consult your doctor immediately for antibiotic treatment.";
        } else if (question.toLowerCase().includes('rejected')) {
          response = "Implant rejection occurs when your body's immune system identifies the implant as foreign. Common symptoms include inflammation, pain, and reduced functionality. Your doctor may recommend immunosuppressants or removing the implant.";
        } else if (question.toLowerCase().includes('recovery') || question.toLowerCase().includes('healing')) {
          response = "Recovery time varies depending on the implant type and your overall health. Generally, follow your doctor's instructions, take prescribed medications, keep the area clean, and attend all follow-up appointments.";
        }
        
        setIsTyping(false);
        resolve(response);
      }, 1500);
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: 'user',
      timestamp: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    
    // Generate AI response
    const responseText = await generateResponse(input);
    
    // Add AI message
    const aiMessage: Message = {
      id: (Date.now() + 1).toString(),
      content: responseText,
      sender: 'system',
      timestamp: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, aiMessage]);
  };

  // Auto scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex flex-col h-[500px] bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="bg-teal-600 text-white px-4 py-3">
        <h3 className="text-lg font-medium">Medical Assistant</h3>
        <p className="text-xs text-teal-100">Ask questions about your implant or treatment</p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center text-gray-500 my-8">
            <Bot className="h-12 w-12 mx-auto text-gray-300 mb-2" />
            <p>Ask me anything about your implant or treatment plan!</p>
          </div>
        ) : (
          messages.map((message) => (
            <div 
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div 
                className={`max-w-[80%] rounded-lg px-4 py-2 ${
                  message.sender === 'user' 
                    ? 'bg-teal-600 text-white rounded-br-none' 
                    : 'bg-gray-100 text-gray-800 rounded-bl-none'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {message.sender === 'user' ? (
                    <User className="h-4 w-4" />
                  ) : (
                    <Bot className="h-4 w-4" />
                  )}
                  <span className="text-xs">
                    {message.sender === 'user' ? 'You' : 'Medical Assistant'}
                  </span>
                </div>
                <p>{message.content}</p>
                <p className="text-xs opacity-70 text-right mt-1">
                  {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))
        )}
        
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-100 text-gray-800 rounded-lg rounded-bl-none px-4 py-2">
              <div className="flex space-x-1">
                <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce"></div>
                <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                <div className="h-2 w-2 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      <form onSubmit={handleSubmit} className="border-t border-gray-200 p-4 flex">
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about your implant..."
          className="flex-1 border border-gray-300 rounded-l-md py-2 px-3 focus:ring-2 focus:ring-teal-500 focus:border-transparent outline-none"
        />
        <button 
          type="submit"
          disabled={!input.trim()}
          className={`bg-teal-600 text-white px-4 rounded-r-md flex items-center ${
            !input.trim() ? 'opacity-50 cursor-not-allowed' : 'hover:bg-teal-700'
          }`}
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
};

export default Chat;